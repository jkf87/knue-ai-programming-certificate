// 수료증 생성을 위한 기본 설정
const CERTIFICATE_CONFIG = {
  width: 800,
  height: 600,
  backgroundColor: "#ffffff",
  borderColor: "#000000",
  borderWidth: 10,
  fontFamily: "Arial",
  titleSize: 40,
  nameSize: 30,
  dateSize: 20
};

// 수료증 생성 클래스
class CertificateGenerator {
  constructor() {
    // 캔버스 생성
    this.canvas = new Canvas(CERTIFICATE_CONFIG.width, CERTIFICATE_CONFIG.height);
    this.ctx = this.canvas.getContext('2d');
  }

  // 사용자 캐릭터 이미지 가져오기
  async getUserSprite(player) {
    const sprite = player.sprite;
    if (!sprite) {
      throw new Error("캐릭터 이미지를 불러올 수 없습니다.");
    }
    return sprite;
  }

  // 수료증 생성
  async generateCertificate(player, courseTitle, completionDate) {
    // 배경 설정
    this.ctx.fillStyle = CERTIFICATE_CONFIG.backgroundColor;
    this.ctx.fillRect(0, 0, CERTIFICATE_CONFIG.width, CERTIFICATE_CONFIG.height);
    
    // 테두리 그리기
    this.ctx.strokeStyle = CERTIFICATE_CONFIG.borderColor;
    this.ctx.lineWidth = CERTIFICATE_CONFIG.borderWidth;
    this.ctx.strokeRect(
      CERTIFICATE_CONFIG.borderWidth/2, 
      CERTIFICATE_CONFIG.borderWidth/2, 
      CERTIFICATE_CONFIG.width - CERTIFICATE_CONFIG.borderWidth,
      CERTIFICATE_CONFIG.height - CERTIFICATE_CONFIG.borderWidth
    );

    // 제목 추가
    this.ctx.font = `${CERTIFICATE_CONFIG.titleSize}px ${CERTIFICATE_CONFIG.fontFamily}`;
    this.ctx.textAlign = "center";
    this.ctx.fillStyle = "#000000";
    this.ctx.fillText("수료증", CERTIFICATE_CONFIG.width/2, 100);

    // 사용자 캐릭터 이미지 추가
    const sprite = await this.getUserSprite(player);
    const spriteSize = 100;
    this.ctx.drawImage(
      sprite,
      (CERTIFICATE_CONFIG.width - spriteSize)/2,
      150,
      spriteSize,
      spriteSize
    );

    // 이름 추가
    this.ctx.font = `${CERTIFICATE_CONFIG.nameSize}px ${CERTIFICATE_CONFIG.fontFamily}`;
    this.ctx.fillText(player.name, CERTIFICATE_CONFIG.width/2, 300);

    // 과정명 추가
    this.ctx.fillText(courseTitle, CERTIFICATE_CONFIG.width/2, 350);

    // 날짜 추가
    this.ctx.font = `${CERTIFICATE_CONFIG.dateSize}px ${CERTIFICATE_CONFIG.fontFamily}`;
    this.ctx.fillText(completionDate, CERTIFICATE_CONFIG.width/2, 450);

    return this.canvas.toDataURL();
  }
}

// Zep 미니게임 초기화
Game.onInit.Add(function() {
  let certificateWidget = null;

  // 수료증 생성기 오브젝트 생성
  const certificateGenerator = Game.createObject();
  certificateGenerator.sprite = "zep_icon_32.png"; // 안경 쓴 캐릭터 아이콘
  certificateGenerator.x = 100; // 원하는 x 좌표
  certificateGenerator.y = 100; // 원하는 y 좌표
  
  // 수료증 생성기에 상호작용 추가
  certificateGenerator.onClick = function(player) {
    try {
      // 이미 열려있는 위젯이 있다면 닫기
      if (certificateWidget) {
        certificateWidget.destroy();
      }

      // 위젯 생성
      certificateWidget = Game.showWidget("certificate.html", "middle", 600, 800);

      // 위젯에 데이터 전송
      certificateWidget.sendMessage({
        type: "certificate",
        spriteUrl: player.sprite,
        playerName: player.name,
        courseTitle: "인공지능 프로그래밍 1 / AI Programming 1",
        date: new Date().toLocaleDateString()
      });

      // 생성 알림
      player.showCenterLabel("수료증이 생성되었습니다!");

    } catch (error) {
      player.showCenterLabel("수료증 생성에 실패했습니다.");
      console.error(error);
    }
  };

  // 마우스 오버시 설명 표시
  certificateGenerator.onTriggerEnter = function(player) {
    player.showCenterLabel("클릭하여 수료증 생성하기");
  };

  // 마우스가 벗어나면 설명 숨기기
  certificateGenerator.onTriggerExit = function(player) {
    player.showCenterLabel("");
  };
}); 