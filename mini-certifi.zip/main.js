import CertificateGenerator from "./certificate";

// Zep 미니게임 초기화
Game.onInit.Add(function() {
  let certificateWidget = null;

  // 수료증 생성기 오브젝트 생성
  const certificateGenerator = Game.createObject();
  certificateGenerator.sprite = "zep_icon_32.png"; // 안경 쓴 캐릭터 아이콘
  certificateGenerator.x = 100; // 원하는 x 좌표
  certificateGenerator.y = 100; // 원하는 y 좌표
  
  // 수료증 생성기에 상호작용 추가
  certificateGenerator.onClick = function(player) {
    try {
      // 이미 열려있는 위젯이 있다면 닫기
      if (certificateWidget) {
        certificateWidget.destroy();
      }

      // 위젯 생성
      certificateWidget = Game.showWidget("certificate.html", "middle", 600, 800);

      // 위젯에 데이터 전송
      certificateWidget.sendMessage({
        type: "certificate",
        spriteUrl: player.sprite,
        playerName: player.name,
        courseTitle: "인공지능 프로그래밍 1 / AI Programming 1",
        date: new Date().toLocaleDateString()
      });

      // 생성 알림
      player.showCenterLabel("수료증이 생성되었습니다!");

    } catch (error) {
      player.showCenterLabel("수료증 생성에 실패했습니다.");
      console.error(error);
    }
  };

  // 마우스 오버시 설명 표시
  certificateGenerator.onTriggerEnter = function(player) {
    player.showCenterLabel("클릭하여 수료증 생성하기");
  };

  // 마우스가 벗어나면 설명 숨기기
  certificateGenerator.onTriggerExit = function(player) {
    player.showCenterLabel("");
  };
}); 